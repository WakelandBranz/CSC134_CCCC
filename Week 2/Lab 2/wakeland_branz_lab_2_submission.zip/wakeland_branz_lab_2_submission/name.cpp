// This program will write the name, address and telephone
// number of the programmer.

// Wakeland Branz

#include <iostream>
using namespace std;

int main()
{
	// Fill in this space to write your first and last name
	cout <<  "Programmer: Wakeland Branz\n";
	// Fill in this space to write your address (on new line)
	cout << "            1600 Briar Chapel Pkwy\n";
	// Fill in this space to write you city, state and zip (on new line)
	cout << "            Chapel Hill, NC. 27516\n\n\n";
	// Fill in this space to write your telephone number (on new line)
	cout << " Telephone: 123-456-7890\n";

	return 0;
}